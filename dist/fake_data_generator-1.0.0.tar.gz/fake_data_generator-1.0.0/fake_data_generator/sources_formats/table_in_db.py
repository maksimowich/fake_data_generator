import copy
import pandas as pd
import sys
import sqlalchemy
from fake_data_generator.columns_generator import get_fake_data_for_columns, ColumnInfo
from sqlalchemy import text
from enum import Enum
from loguru import logger


logger.remove(0)
logger.add(sys.stdout, format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | <cyan>{message}</cyan>")


class DatabaseName(Enum):
    POSTGRES = {
        'describe_query': "SELECT column_name, data_type FROM information_schema.columns "
                          "WHERE table_schema = '{source_table_schema}' AND table_name = '{source_table_name}';"
        }

    @property
    def describe_query(self):
        return self.value['describe_query']


def generate_fake_table(engine: sqlalchemy.engine.base.Engine,
                        source_table_name_with_schema: str,
                        dest_table_name_with_schema: str,
                        output_size: int,
                        number_of_rows_from_which_to_create_pattern: int,
                        db: DatabaseName = DatabaseName.POSTGRES,
                        columns_info: list[ColumnInfo] = None,
                        columns_to_include: list[str] = None):
    string_for_column_names = ','.join(map(lambda x: '"' + x + '"', columns_to_include)) if columns_to_include is not None else '*'
    logger.info(f"generate_fake_postgres_table function was called."
                f"\n\tSource table: {source_table_name_with_schema}"
                f"\n\tColumns of source table to include in destination table: ({string_for_column_names})"
                f"\n\tDestination table: {dest_table_name_with_schema}"
                f"\n\tNumber of rows to insert into destination table: {output_size}"
                f"\n\tNumber of source table`s rows from which to create pattern: {number_of_rows_from_which_to_create_pattern}"
                f"\n\tDatabase: {db}")

    logger.info('Start making describe-query for column data types info.')
    column_names_and_types_in_df = pd.read_sql_query(sql=db.describe_query.format(source_table_schema=source_table_name_with_schema.split('.')[0],
                                                                                  source_table_name=source_table_name_with_schema.split('.')[1]),
                                                     con=engine)
    column_names_to_types_dict = column_names_and_types_in_df.set_index('column_name')['data_type'].to_dict()
    logger.info('Column names and types were fetched.')

    logger.info(f'Start making select-query from table {source_table_name_with_schema}.')
    table_data_in_df = pd.read_sql_query(sql=f"SELECT {string_for_column_names} "
                                             f"FROM {source_table_name_with_schema} "
                                             f"ORDER BY RANDOM() "
                                             f"LIMIT {number_of_rows_from_which_to_create_pattern}",
                                         con=engine,
                                         parse_dates=[col_name for col_name, col_type in column_names_to_types_dict.items() if col_type in ('date', 'timestamp')])
    logger.info(f'Select-query result was read into Dataframe. Number of rows fetched is {table_data_in_df.shape[0]}.')

    columns_info_in_dict = {column_info.get_column_name(): copy.deepcopy(column_info) for column_info in columns_info}
    for col_name, col_type in column_names_to_types_dict.items():
        if col_name not in columns_info_in_dict:
            columns_info_in_dict[col_name] = ColumnInfo(col_name, column_type=col_type)
        else:
            columns_info_in_dict.get(col_name).set_column_type(col_type)

    fake_data_in_df = get_fake_data_for_columns(data_in_df=table_data_in_df,
                                                output_size=output_size,
                                                columns_info=columns_info_in_dict,
                                                engine=engine)

    logger.info(f'Start recreating {dest_table_name_with_schema} table.')
    with engine.begin() as conn:
        conn.execute(text(f'DROP TABLE IF EXISTS {dest_table_name_with_schema};'))
        conn.execute(text(f'CREATE TABLE {dest_table_name_with_schema} AS '
                          f'SELECT {string_for_column_names} '
                          f'FROM {source_table_name_with_schema} '
                          'WHERE 1<>1;'))
    logger.info(f'{dest_table_name_with_schema} table was recreated.')

    logger.info(f'Start inserting generated fake data into {dest_table_name_with_schema} table.')
    number_of_rows_inserted = fake_data_in_df.to_sql(name=dest_table_name_with_schema.split('.')[1],
                                                     schema=dest_table_name_with_schema.split('.')[0],
                                                     con=engine,
                                                     index=False,
                                                     if_exists='append')
    logger.info(f'Insertion of fake data into {dest_table_name_with_schema} was finished.'
                f'\n\tNumber of rows inserted: {number_of_rows_inserted}\n')
