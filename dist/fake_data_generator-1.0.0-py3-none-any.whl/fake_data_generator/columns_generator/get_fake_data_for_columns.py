import json
import numpy as np
import pandas as pd
import sqlalchemy
from fake_data_generator.columns_generator.get_common_regex import get_common_regex
from fake_data_generator.columns_generator.column_info import ColumnInfo
from datetime import timedelta
from loguru import logger
from pathlib import Path
from random import randint, uniform
from rstr import xeger
from scipy.stats import gaussian_kde


def get_fake_data_for_categorical_column(column_values: pd.Series,
                                         output_size: int) -> pd.Series:
    normalized_frequencies_of_values = column_values.value_counts(normalize=True)
    fake_sample = np.fake.choice(a=normalized_frequencies_of_values.index.tolist(),
                                 p=normalized_frequencies_of_values.to_list(),
                                 size=output_size,
                                 replace=True)
    return pd.Series(fake_sample, name=column_values.name)


def get_fake_data_for_number_column(column_values: pd.Series,
                                    output_size: int) -> pd.Series:
    column_values_without_nulls = column_values.dropna()
    kde = gaussian_kde(column_values_without_nulls.values)
    x = np.linspace(min(column_values_without_nulls), max(column_values_without_nulls), num=1000)
    pdf = kde.evaluate(x)
    if column_values.dtype == np.float64:
        precisions = [len(str(float_number).split('.')[-1]) for float_number in column_values]
        precision = int(np.median(precisions))
    fake_sample = map(lambda value: int(value) if column_values.dtype == np.int64 else round(value, precision),
                      np.fake.choice(a=x, size=output_size, p=pdf / sum(pdf), replace=True))
    return pd.Series(fake_sample, name=column_values.name)


def get_fake_data_for_date_column(column_values: pd.Series,
                                  output_size: int) -> pd.Series:
    start_date = min(column_values)
    end_date = max(column_values)
    range_in_days = (end_date - start_date).days
    fake_dates = [start_date + timedelta(days=randint(1, range_in_days)) for _ in range(output_size)]
    return pd.Series(fake_dates, name=column_values.name)


def get_fake_data_for_timestamp_column(column_values: pd.Series,
                                       output_size: int) -> pd.Series:
    start_timestamp = min(column_values)
    end_timestamp = max(column_values)
    range_in_sec = (end_timestamp - start_timestamp).total_seconds()
    fake_timestamps = [start_timestamp + timedelta(seconds=uniform(0, range_in_sec)) for _ in range(output_size)]
    return pd.Series(fake_timestamps, name=column_values.name)


def get_fake_data_for_string_column(column_values: pd.Series,
                                    output_size: int,
                                    column_info: ColumnInfo) -> pd.Series:
    if column_info.get_faker_function() is None:
        common_regex = column_info.get_regex() or get_common_regex(column_values)
        list_of_fake_strings = [xeger(common_regex) for _ in range(output_size)]
    else:
        faker_function = column_info.get_faker_function()
        list_of_fake_strings = [faker_function() for _ in range(output_size)]
    return pd.Series(list_of_fake_strings, name=column_values.name)


def get_data_for_id_column(column_values: pd.Series,
                           output_size: int) -> pd.Series:
    list_of_ids = []
    if column_values.dtype == np.int64:
        list_of_ids = [incremental_id for incremental_id in range(1, output_size + 1)]
    else:
        common_regex = get_common_regex(column_values)
        for _ in range(output_size):
            while True:
                fake_id_in_string = xeger(common_regex)
                if fake_id_in_string not in list_of_ids:
                    list_of_ids.append(fake_id_in_string)
                    break
    return pd.Series(list_of_ids, name=column_values.name)


def get_fake_data_for_fk_column(ref_table_name_with_schema_or_file_path: str,
                                ref_column_name: str,
                                dest_column_name: str,
                                output_size: int,
                                engine=None,
                                ref_file_encoding: str = 'utf-8') -> pd.Series:
    if engine is not None:
        fake_data = pd.DataFrame(columns=[ref_column_name])
        while output_size > len(fake_data):
            fake_data = pd.concat([fake_data, pd.read_sql_query(sql=f"SELECT {ref_column_name} "
                                                                    f"FROM {ref_table_name_with_schema_or_file_path} "
                                                                    "ORDER BY fake() "
                                                                    f"LIMIT {output_size - fake_data.shape[0]}",
                                                                    con=engine)], ignore_index=True)
        return fake_data[ref_column_name].rename(dest_column_name)
    else:
        extension = Path(ref_table_name_with_schema_or_file_path).suffix
        if extension == '.csv':
            csv_in_df = pd.read_csv(filepath_or_buffer=ref_table_name_with_schema_or_file_path,
                                    usecols=[ref_column_name],
                                    encoding=ref_file_encoding)
            fake_sample = csv_in_df.sample(n=output_size, replace=True, ignore_index=True)
            return fake_sample[ref_column_name].rename(dest_column_name)
        else:
            return pd.Series([None] * output_size, name=dest_column_name)


def get_value_by_path(dictionary: dict, keys_path: tuple):
    value = dictionary
    for key in keys_path:
        if key in value:
            value = value[key]
        else:
            return None
    return value


def set_value_by_key_path(dictionary: dict,
                          key_path: tuple,
                          value):
    current_dictionary = dictionary
    for index, key in enumerate(key_path):
        if not isinstance(current_dictionary.get(key), dict) and index < len(key_path) -1:
            current_dictionary[key] = {}
            current_dictionary = current_dictionary[key]
        elif isinstance(current_dictionary.get(key), dict) and index < len(key_path) -1:
            current_dictionary = current_dictionary[key]
        else:
            current_dictionary[key] = value


def traverse_json_keys_and_create_list_of_series(column_values: pd.Series,
                                                 keys_path: tuple = None):
    if keys_path is None:
        keys_path = tuple()
    list_of_series_for_json = []
    processed_json_keys = []
    for index in range(column_values.count()):
        column_value = get_value_by_path(column_values[index], keys_path)
        for json_key, value in column_value.items():
            if json_key in processed_json_keys:
                continue
            else:
                processed_json_keys.append(json_key)
                if not isinstance(value, dict):
                    list_of_series_for_json.append(pd.Series(data=[get_value_by_path(column_value, keys_path + (json_key,)) for column_value in column_values],
                                                             name='->'.join(keys_path + (json_key,))))
                else:
                    list_of_series_for_json = list_of_series_for_json + traverse_json_keys_and_create_list_of_series(column_values, keys_path + (json_key,))
    return list_of_series_for_json


def get_fake_data_for_json(column_values: pd.Series,
                           column_info: ColumnInfo,
                           output_size: int,
                           engine):
    list_of_json_series = traverse_json_keys_and_create_list_of_series(column_values)
    list_of_dicts_with_fake_data = [{} for _ in range(output_size)]
    for json_series in list_of_json_series:
        column_of_json_info = next((column_of_json_info for column_of_json_info in column_info.get_json_info()
                                    if json_series.name == column_of_json_info.get_column_name()),
                                   ColumnInfo(column_name=json_series.name))
        fake_json_series = get_fake_data_for_column(json_series,
                                                    column_of_json_info,
                                                    output_size,
                                                    engine)
        for index, value in enumerate(fake_json_series):
            key_path = fake_json_series.name.split('->')
            set_value_by_key_path(list_of_dicts_with_fake_data[index], key_path, value)
    return pd.Series(list(map(lambda x: json.dumps(x), list_of_dicts_with_fake_data)), name=column_values.name)


def get_fake_data_for_column(column_values: pd.Series,
                             column_info: ColumnInfo,
                             output_size: int,
                             engine: sqlalchemy.engine.base.Engine) -> pd.Series:
    if column_info.get_fk() is not None:
        logger.info(f'Column "{column_values.name}" — FOREIGN KEY -> {column_info.get_fk()}')
        return get_fake_data_for_fk_column(ref_table_name_with_schema_or_file_path=column_info.get_fk().get_ref_table_name_with_schema_or_file_path(),
                                           ref_column_name=column_info.get_fk().get_ref_column_name(),
                                           dest_column_name=column_values.name,
                                           output_size=output_size,
                                           engine=engine)

    if column_values.isnull().all():
        return pd.Series([None] * output_size, name=column_values.name)

    if 'json' in (column_info.get_column_type() or ''):
        logger.info(f'Column "{column_values.name}" — JSON COLUMN')
        return get_fake_data_for_json(column_values, column_info, output_size, engine)

    categorical_column_flag = column_info.get_categorical_flag() or (column_values.nunique() / column_values.count() < 0.5)
    id_flag = column_info.get_id_flag() or False

    if categorical_column_flag:
        logger.info(f'Column "{column_values.name}" — CATEGORICAL COLUMN')
        return get_fake_data_for_categorical_column(column_values, output_size)
    elif id_flag:
        logger.info(f'Column "{column_values.name}" — ID COLUMN')
        return get_data_for_id_column(column_values, output_size)
    else:
        if column_values.dtype == np.int64 or column_values.dtype == np.float64:
            logger.info(f'Column "{column_values.name}" — NUMBER COLUMN')
            return get_fake_data_for_number_column(column_values, output_size)
        elif column_info.get_column_type() == 'date':
            logger.info(f'Column "{column_values.name}" — DATE COLUMN')
            return get_fake_data_for_date_column(column_values, output_size)
        elif 'timestamp' in column_info.get_column_type():
            logger.info(f'Column "{column_values.name}" — TIMESTAMP COLUMN')
            return get_fake_data_for_timestamp_column(column_values, output_size)
        elif column_values.dtype == np.dtype(object):
            logger.info(f'Column "{column_values.name}" — STRING NON CATEGORICAL COLUMN')
            return get_fake_data_for_string_column(column_values, output_size, column_info)


def get_fake_data_for_columns(data_in_df: pd.DataFrame,
                              output_size: int,
                              columns_info: dict[str, ColumnInfo],
                              engine: sqlalchemy.engine.base.Engine = None) -> pd.DataFrame:
    logger.info(f'-----------Start generating fake data-----------')
    list_of_fake_column_data = []
    for index, (column_name, column_data) in enumerate(data_in_df.items()):
        logger.info(f'{index}) Start generating fake data for "{column_name}" column.')
        fake_column_data_in_series = get_fake_data_for_column(column_values=column_data,
                                                              column_info=columns_info.get(column_name, ColumnInfo(column_name)),
                                                              output_size=output_size,
                                                              engine=engine)
        list_of_fake_column_data.append(fake_column_data_in_series)
        logger.info(f'{index}) Fake data for {column_name} was generated.')
    df_to_insert = pd.concat(list_of_fake_column_data, axis=1)
    logger.info(f'-----------Fake data for all columns was generated-----------')
    return df_to_insert
